#!/bin/bash


while IFS= read -r line; do
    # 从每行中提取第一列、第二列和第三列的内容
    column1=$(echo "$line" | awk '{print $1}')
    
    # 调用B脚本，并将提取的三个值传递给它
    echo "在目标文件中读取到" "$column1"
    bash O_genome_blastn.sh "$column1"
done < /mnt/vol1/wangxuesong/run-tree/structural_tree/all_species.txt