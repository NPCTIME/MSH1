# !/bin/bash

# 提取所有得分大于130的蛋白序列和对应的编码序列【130是利用拟南芥的MSH1蛋白序列针对拟南芥的全基因组蛋白序列运行blstp后得出的参考值，130是MSH家族其它基因中与MSH1最相近的蛋白的得分，高于这个得分的片段即认为可以选为候选序列】

export PATH="/usr/software/anaconda3/bin:$PATH"
# blastp添加到路径变量
export PATH="/home/liaoxuezhu/anaconda3/lib/python3.8/site-packages/tree2gd/software:$PATH"
# seqkit添加到路径变量
genome_storage="/mnt/vol1/wangxuesong/species_storage"
query=/mnt/vol1/wangxuesong/evolution_analyse/AtMSH1.fasta
specie="$1"
# 总文件夹位置/查询序列绝对路径/所运行的物种
specie_genome=${genome_storage}/${specie}/${specie}_DNA.fasta
specie_GFF=${genome_storage}/${specie}/${specie}_GFF.gff

if [ ! -e "${genome_storage}/${specie}/${specie}_GFF.gff" ]; then
echo "缺少注释文件 请检查基因组注释文件文件名规范或补充基因组对应注释文件"
exit 1
fi
# 判断是否有通过blastp进行序列寻找的基础，有GFF文件才会继续运行下面的代码

if [ -e "${genome_storage}/${specie}/${specie}_PRO.protein.fa" ]; then
    specie_cds=${genome_storage}/${specie}/${specie}_CDS.cds.fa
    specie_protein=${genome_storage}/${specie}/${specie}_PRO.protein.fa
else
    echo "作者未发布全基因组蛋白和CDS文件启用GFF提取序列"
    specie_cds=${genome_storage}/${specie}/${specie}_GRD_CDS.cds.fa
    specie_protein=${genome_storage}/${specie}/${specie}_GRD_PRO.protein.fa
fi
# 基因组文件的绝对路径 根据作者发布的基因组文件的情况进行全基因组文件的情况查询

PROseq_storage=/mnt/vol1/wangxuesong/run-tree/specie_protein
CDSseq_storage=/mnt/vol1/wangxuesong/run-tree/specie_coding
DNAseq_storage=/mnt/vol1/wangxuesong/run-tree/specie_allseq
# 存放提取的序列的位置
cd ${genome_storage}/${specie}

touch ${genome_storage}/${specie}/${specie}_seqinforamtion.txt
> ${genome_storage}/${specie}/${specie}_seqinforamtion.txt
# 清除之前运行中积累的坐标信息数据

# 直接运行blastp
echo "正在用blastp筛选候选序列"
blastp -query "$query" -subject "$specie_protein" -outfmt 6 -out "${specie}_blastp_result.txt"
# 裁剪结果文件，保留所需结果ID【{1}BLASTP运行结果】
awk '$12 >= 130' ${specie}_blastp_result.txt | awk '{print $2}' > ${specie}_protein_id.txt
echo "剪切候选序列,将可能的序列ID均保存下来"
# 获得候选蛋白ID【{2}提取候选MSH1序列的蛋白ID】
input_file=${specie}_protein_id.txt

line_number=1
# 设定号起始行号变量


# 逐行读取蛋白ID文件
while IFS= read -r protein_id; do
    echo "当前寻找的序列为blastp结果中第"${line_number}"行的编号为"${protein_id}"的蛋白"
    # 输入文件包含蛋白ID的文本文件
    
    output_file=${specie}_protein_id_coordinate_${line_number}.txt
    # 输出文件
    id_coordinate="${genome_storage}/${specie}/${specie}_${line_number}_coordinate.txt"
    # 设定存储中间信息的文件
    
    > "$output_file"
    # 清空输出文件【输入空白内容清空输出文件】
    
    awk -i inplace '/^>/{sub("\t.*", "")}1' ${specie_protein}
    # 删除序列ID行中第一个制表符之后的内容 避免seqkit提取时出现问题
    seqkit grep -p "${protein_id}" ${specie_protein} > PRO_${specie}_${line_number}.fasta
    # 用seqkit来获取编码MSH1的蛋白序列【蛋白id前面不需要添加>】
    echo "正在根据序列ID提取蛋白序列"
    sed -i "1s/.*/>${specie}_${line_number}_${protein_id}/" PRO_${specie}_${line_number}.fasta
    # 修改提取序列的第一行为自定义的格式
    echo "提取的蛋白序列为"
    cat PRO_${specie}_${line_number}.fasta
    cp PRO_${specie}_${line_number}.fasta ${PROseq_storage}/PRO_${specie}_${line_number}.fasta
    # 复制一份蛋白序列到另一个总的文件夹
    
    echo "正在利用tblastn寻找对应cds序列"
    tblastn -query PRO_${specie}_${line_number}.fasta -subject "$specie_cds" -outfmt 6 -out "${specie}_tblastn_result_${line_number}.txt"
    # 利用蛋白序列搜索对应的CDS序列
    tblastn_result=${genome_storage}/${specie}/${specie}_tblastn_result_${line_number}.txt
    cds_id=$(awk 'NR==1 {print $2}' "${tblastn_result}")
    # 将第一行第二列的值赋值给cds_id
    echo "蛋白对应的CDS序列ID为"${cds_id}

    echo "正在根据序列ID提取序列"
    awk -i inplace '/^>/{sub("\t.*", "")}1' ${specie_cds}
    # 删除序列ID行中第一个制表符之后的内容 避免seqkit提取时出现问题
    seqkit grep -p "${cds_id}" ${specie_cds} > RNA_${specie}_${line_number}.fasta
    # 用seqkit提取MSH1的编码序列
    sed -i "1s/.*/>${specie}_${line_number}_${cds_id}/" RNA_${specie}_${line_number}.fasta
    # 修改提取序列的第一行为自定义的格式
    echo "提取的CDS序列为"
    cat RNA_${specie}_${line_number}.fasta
    cp RNA_${specie}_${line_number}.fasta ${CDSseq_storage}/RNA_${specie}_${line_number}.fasta
    # 复制一份编码序列到一个用来建树的文件夹
    grep "$cds_id" "$specie_GFF" >> "$id_coordinate"
    # 提取GFF文件中出现过CDS相关的序列的行到一个中间文档$id_coordinate【${specie}_${line_number}_coordinate.txt】中
    if [ ! -s "$id_coordinate" ]; then
    echo "GFF文件中CDS的ID对应序列为空"
    exit 1  # 终止脚本的执行
    fi
    column -t -s$'\t' "$id_coordinate" > temp.txt
  mv temp.txt "$id_coordinate"
  # 利用column将GFF文件输出的行进行规整
  # awk '{print $4; print $5}' "$id_coordinate" > ${genome_storage}/${specie}/${specie}_tmp_numbers_${line_number}.txt
  # if [ ! -s "${specie}_tmp_numbers_${line_number}.txt" ]; then
  # echo "序列ID在基因组上的坐标提取为空"
  # exit 1  # 终止脚本的执行
  # fi
  # # 提取第四列和第五列的数字到一个中间文档中
  # chr=$(awk 'NR==1 {print $1}' "$id_coordinate")
  # X=$(sort -n ${specie}_tmp_numbers_${line_number}.txt | head -n 1)
  # Y=$(sort -n ${specie}_tmp_numbers_${line_number}.txt | tail -n 1)
  # # 计算最大值和最小值并保存到变量
  # echo ${cds_id}"的染色体坐标为"${chr} "染色体上的序列为"${X}"至"${Y}
  # # 先提取指定序列
  # seqkit grep -r -p "${chr}" ${specie}_DNA.fasta > chr_${line_number}.fasta
  # echo "已经将"${specie}"基因组中编号为"${chr}"的基因组片段序列复制到独立文件"
  # awk -i inplace '/^>/{sub("\t.*", "")}1' chr_${line_number}.fasta
  # seqkit subseq chr_${line_number}.fasta -r ${X}:${Y} > DNA_${specie}_${line_number}.fasta
  # sed -i "1s/.*/>${specie}_${line_number}_${cds_id}_${X}-${Y}/" DNA_${specie}_${line_number}.fasta
  # # rm chr_${line_number}.fasta
  # cp DNA_${specie}_${line_number}.fasta ${DNAseq_storage}/DNA_${specie}_${line_number}.fasta
  # sed -i "1s/.*/>${specie}_${line_number}_${cds_id}/" ${DNAseq_storage}/DNA_${specie}_${line_number}.fasta
  # if [ -f "${DNAseq_storage}/DNA_${specie}_${line_number}.fasta" ]; then
  #   rm chr_${line_number}.fasta
  #   rm chr_${line_number}.fasta.seqkit.fai
  #   rm DNA_${specie}_${line_number}.fasta
  #   echo ${specie}"的"    ${line_number}  "号序列在基因组上的全长序列提取成功"
  # fi



    # grep "$cds_id" "$specie_GFF" >> "$output_file"
    # awk '{print $4; print $5}' "$output_file" > ${specie}_tmp_numbers_${line_number}.txt
    # # 提取第四列和第五列的数字到一个中间文档中
    # chr=$(awk 'NR==1 {print $1}' "$output_file")
    # X=$(sort -n ${specie}_tmp_numbers_${line_number}.txt | head -n 1)
    # Y=$(sort -n ${specie}_tmp_numbers_${line_number}.txt | tail -n 1)
    # # 计算最大值和最小值并保存到变量
    # echo ${cds_id}"的染色体坐标为"${chr} "染色体上的序列为"${X}"至"${Y}

    # # 提取蛋白ID对应的GFF文件中的信息
    # echo "现在正在提取的是"${specie}"的"${number}"号基因序列"
    # awk -i inplace '/^>/{sub("\t.*", "")}1' ${specie_genome}
    # # 清洗基因组文件ID行
    # start_line=$(grep -n "$chr" "$specie_genome" | head -n 1 | cut -d ':' -f 1)
    # # 通过搜索染色体ID找到对应ID的起始行 然后进行搜索
    # echo "基因组内"${chr}"起始序列已定位行号 序列将从"${start_line}"开始"
    # # 搜索下一个>的起始行
    # next_start_line=$(awk -v start="$start_line" '/^>/ && NR > start { print NR; exit }' "$specie_genome")
    # if [ -n "$next_start_line" ]; then
    #  end_line=$((next_start_line - 1))
    #  else
    #  end_line=$(wc -l < "$specie_genome")
    #  fi
    #  echo "基因组内"${chr}"染色体尾部行号已定位" ${end_line}
    #  # 如果找不到目标序列，输出错误信息并退出
    #  if [ -z "$start_line" ]; then
    # echo "目标序列未找到 请检查染色体序列ID"
    # exit 1
    # fi
    # echo "序列搜索范围已确定,基因序列从"${X}"到"${Y}"染色体编号为"${chr}
    # # 提取目标序列的内容
    # target_content=$(sed -n "${start_line},${end_line}p" "$specie_genome")
    # echo "target_content已提取"
    # # 从目标内容中提取序列内容（除第一行外的所有行）
    # sequence_content=$(echo "$target_content" | tail -n +2 | tr -d '\n')
    # echo "sequence_content已提取"
    # extracted_sequence="${sequence_content:(X - 1):(Y - X + 1)}"
    # echo "正在提取基因全长序列"
    # echo ">${specie}_${line_number}_${cds_id} \n$extracted_sequence" | tee DNA_${specie}_${line_number}.fasta ${DNAseq_storage}/DNA_${specie}_${line_number}.fasta

    echo "${specie} ${line_number} ${protein_id} ${cds_id} ${chr} ${X} ${Y}" >> ${genome_storage}/${specie}/${specie}_seqinforamtion.txt
    # 整理提取到的序列编号坐标等信息
    ((line_number++))

done < "$input_file"
echo "匹配的行已保存到 $output_file"


# # 蛋白ID直接提取试验工具
# seqkit grep -p "TuG1812G0200004106.01.T01" ${specie_protein}
























# # 获取蛋白序列

# # 运用tblastn获取对应CDS序列和CDS的ID














# # # 读取species.txt文档的每一行，逐行处理，每个物种依次处理
# # while IFS= read -r current_specie; do
# #     # 输出 SPE_PRO.fasta 是否存在的信息
# #     if [ -e "Species_Storage/${current_specie}/${current_specie}_PRO.protein.fa" ]; then
# #         echo "已经搜索到Species_Storage/${current_specie}/${current_specie}_PRO.protein.fa""当前进行blast的物种是" ${current_specie}
# #         run_blastp "AtMSH1.fasta" "Species_Storage/$current_specie/${current_specie}_PRO.protein.fa" "blastp_result/${current_specie}_"
# #         awk '$12 >= 130' blastp_result/${current_specie}_blastp_result.txt > blastp_result/${current_specie}_modify_result.txt
# #     else
# #         echo "$current_specie 的物种文件未在Species_Storage/$current_specie 下找到,请检查序列"
# #     fi
# # done < "sort_species.txt"

# #提取序列ID


# # # 手动小工具
# # 
# # /usr/software/anaconda3/bin/blastp -query /mnt/vol1/wangxuesong/evolution_storage/AtMSH1.fasta -subject /mnt/vol1/wangxuesong/evolution_storage/Species_Storage/04-02_hai-bin-zhang-mao/04-02_hai-bin-zhang-mao_change_PRO.protein.fa -outfmt 6 -out /mnt/vol1/wangxuesong/evolution_storage/blastp_result/04-02_hai-bin-zhang-mao_blastp_result.txt
# # # 2、全基因组蛋白序列提取
# # /usr/software/gffread/gffread /mnt/vol1/wangxuesong/evolution_storage/Species_Storage/06-01_Pharus+latifolius/06-01_Pharus+latifolius_GFF.gff -g /mnt/vol1/wangxuesong/evolution_storage/Species_Storage/06-01_Pharus+latifolius/06-01_Pharus+latifolius_DNA.fasta -y /mnt/vol1/wangxuesong/evolution_storage/Species_Storage/06-01_Pharus+latifolius/06-01_Pharus+latifolius_PRO_gffread.protein.fa

# # /usr/software/gffread/gffread 06-01_Pharus+latifolius_GFF.gff -g 06-01_Pharus+latifolius_DNA.fasta -y 06-01_Pharus+latifolius_PRO_gffread.protein.fa
# # # 3、全基因组CDS序列提取小工具

