# !/bin/bash
export PATH="/home/liaoxuezhu/anaconda3/lib/python3.8/site-packages/tree2gd/software:$PATH"
# 用于通过分析全基因组序列的tblastn结果利用染色体ID和坐标提取序列
specie="$1"
number="$2"
chr="$3"
X="$5"
Y="$4"
cd /mnt/vol1/wangxuesong/species_storage/${specie}
# 计算最大值和最小值并保存到变量
echo "提取"${specie}"的染色体坐标为"${chr} "序列上的"${X}"至"${Y}"的第"${number}"条序列"
# 先提取指定序列
awk -i inplace '/^>/{sub("\t.*", "")}1' ${specie}_DNA.fasta

seqkit grep -r -p "${chr}" ${specie}_DNA.fasta > chr_${number}.fasta
echo "已完成染色体全长序列的提取"
sed -i "1s/.*/>${chr}/" chr_${number}.fasta
seqkit subseq chr_${number}.fasta -r ${X}:${Y} > DNA_${specie}_${number}.fasta
sed -i "1s/.*/>${specie}=${chr}=$X=$Y/" DNA_${specie}_${number}.fasta
cat DNA_${specie}_${number}.fasta | rev > DNA_${specie}_${number}_reversed.fasta
sed -i "1s/.*/>${specie}=${chr}=$Y=$X/" DNA_${specie}_${number}_reversed.fasta
cp DNA_${specie}_${number}.fasta /mnt/vol1/wangxuesong/run-tree/structural_tree/DNA_allseq/new/DNA_${specie}_${number}.fasta
# cp DNA_${specie}_${number}.fasta /mnt/vol1/wangxuesong/run-tree/structural_tree/no_gff_genome/DNA_${specie}_${number}.fasta
