# !/bin/bash

# 将所有文件的格式进行统一，全基因组文件为fasta格式、GFF注释文件为gff格式、蛋白序列文件为.protein.fa格式、转录组和CDS为.cds.fa格式

# 处理习惯：
# 基于物种的科、亚科、属生成一套编号，结合物种的拉丁名命名物种基因组文件，并基于文件的类型添加后缀
# 基因组序列的后缀为_DNA;全基因组CDS序列的后缀为_CDS;全基因组蛋白序列的后缀为_PRO;全基因组注释文件的后缀为_GFF
# 例如Pharus latifolius属于禾本科（编号0）;服叶竺亚科（编号6）;服叶竺属（编号01）,其全基因组CDS序列命名为06-01_Pharus+latifolius_CDS.cds.fa
# 然后将同一物种的所有文件放置在以物种编号加物种名命名的文件夹中,例如Pharus latifolius的文件就放置在06-01_Pharus+latifolius文件夹中,所有的物种文件夹都储存在一个名为species_storage的总物种文件夹

genome_storage=/mnt/vol1/wangxuesong/species_storage

cd ${genome_storage}

find  -type f -name '*_DNA*' -exec sh -c 'mv "$0" "$(echo "$0" | sed "s/_DNA.*$/\_DNA.fasta/")"' {} \;
find  -type f -name '*_RNA*' -exec sh -c 'mv "$0" "$(echo "$0" | sed "s/_RNA.*$/\_CDS.cds.fa/")"' {} \;
find  -type f -name '*_CDS*' -exec sh -c 'mv "$0" "$(echo "$0" | sed "s/_CDS.*$/\_CDS.cds.fa/")"' {} \;
find  -type f -name '*_PRO*' -exec sh -c 'mv "$0" "$(echo "$0" | sed "s/_PRO.*$/\_PRO.protein.fa/")"' {} \;
find  -type f -name '*_GFF*' -exec sh -c 'mv "$0" "$(echo "$0" | sed "s/_GFF.*$/\_GFF.gff/")"' {} \;
# 形成列表用于自动化
find ${genome_storage} -mindepth 1 -maxdepth 1 -type d > species_directory.txt
# 将文件夹下所有文件夹名整理到一个.txt文档中命名为species，其中-mindepth和-maxdepth是用来限制搜索深度的，-type d 是用来限制搜索的类型为文件夹
sed 's|.*/\(.*\)|\1|' species_directory.txt > species.txt
# 基因组文件的提取
# 搜索总文件夹下的所有子文件夹
for dir in /mnt/vol1/wangxuesong/species_storage/*; do
    if [ -d "$dir" ]; then
        # 提取子文件夹的名称
        specie=$(basename "$dir")
        echo $dir
        echo $specie
        # 检查子文件夹是否包含_DNA和_GFF文件
        if [[ $(find "$dir" -type f -name '*_DNA*' -print) && $(find "$dir" -type f -name '*_GFF*' -print) && ! $(find "$dir" -type f -name '*_PRO*' -print) ]]; then
            # 运行gffread来提取全基因组蛋白序列
            /usr/software/gffread/gffread -g "$dir/${specie}_DNA.fasta" -y "$dir/${specie}_GRD_PRO.protein.fa" "$dir/${specie}_GFF.gff"
            
            # 运行gffread来提取全基因组CDS序列
            /usr/software/gffread/gffread -g "$dir/${specie}_DNA.fasta" -x "$dir/${specie}_GRD_CDS.cds.fa" "$dir/${specie}_GFF.gff"
        fi
    fi
done



# sed -i 's/>lcl|/>/g' input.txt
# 清理coge下载的全基因组文件【coge下载的文件会在染色体编号上增加一些字符导致序列提取出现问题】







