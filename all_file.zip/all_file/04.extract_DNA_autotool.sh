#!/bin/bash

# 读取1.txt文档的每一行内容
while IFS= read -r line; do
    # 从每行中提取第一列、第二列和第三列的内容
    column1=$(echo "$line" | awk '{print $1}')
    column2=$(echo "$line" | awk '{print $2}')
    column3=$(echo "$line" | awk '{print $3}')
    column4=$(echo "$line" | awk '{print $4}')
    column5=$(echo "$line" | awk '{print $5}')
    # 调用B脚本，并将提取的三个值传递给它
    echo "目前正在提取的序列编号为""$column2"
    echo "目前正在读取的物种为""$column1" "染色体编号为 $column3 ，序列从 $column5 到 $column4 "
    bash B.get_nogff_seq_copy.sh "$column1" "$column2" "$column3" "$column4" "$column5"
done < /mnt/vol1/wangxuesong/run-tree/structural_tree/allseq_infor_copy.txt
