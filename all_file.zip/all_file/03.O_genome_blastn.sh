# !/bin/bash

# 运用blastn在全基因组中搜索水稻MSH1标准序列的起止位置
export PATH="/usr/software/anaconda3/bin:$PATH"
# 将blast添加到路径变量

genome_storage=/mnt/vol1/wangxuesong/species_storage
query=/mnt/vol1/wangxuesong/run-tree/structural_tree/OSMSH1.fasta
blastn_result=/mnt/vol1/wangxuesong/run-tree/structural_tree/Blastn
specie="$1"


# 总文件夹位置/查询序列绝对路径/所运行的物种
specie_genome=${genome_storage}/${specie}/${specie}_DNA.fasta

echo "正在提取的物种为"${specie}
blastn -query "$query" -subject "$specie_genome" -outfmt 7 -out ${blastn_result}/${specie}_blastnresult.txt