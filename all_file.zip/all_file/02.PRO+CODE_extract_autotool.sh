#!/bin/bash

# 本脚本是为了实现自动化运行/mnt/vol1/wangxuesong/run-tree/structural_tree/02.manual_extract.sh脚本而设计的小工具，未设置绝对路径，请将本脚本与02.manual_extract.sh放置在同一文件夹下

# 基于所有的物种名生成一个文件allright_species.txt【文件中只包含物种编号及拉丁名 如 01-12_Triticum+aestivum】


while IFS= read -r line; do
    # 从每行中提取第一列、第二列和第三列的内容
    column1=$(echo "$line" | awk '{print $1}')
    
    # 调用B脚本，并将提取的三个值传递给它
    echo "$column1"
    bash 02.PRO+CODE_extract.sh "$column1"
done < /mnt/vol1/wangxuesong/run-tree/structural_tree/allright_species.txt












# 读取1.txt文档的每一行内容
# while IFS= read -r line; do
#     # 从每行中提取第一列、第二列和第三列的内容
#     column1=$(echo "$line" | awk '{print $1}')
#     column2=$(echo "$line" | awk '{print $2}')
#     column3=$(echo "$line" | awk '{print $3}')
    
#     # 调用B脚本，并将提取的三个值传递给它
#     echo "$column1" "$column2" "$column3"
#     bash extract_DNA_seq.sh "$column1" "$column2" "$column3"
# done < /mnt/vol1/wangxuesong/run-tree/structural_tree/specie_infor.txt